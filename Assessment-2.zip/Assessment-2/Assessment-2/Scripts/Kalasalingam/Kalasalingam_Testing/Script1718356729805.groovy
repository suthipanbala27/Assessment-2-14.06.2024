import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://kalasalingam.ac.in/')

WebUI.click(findTestObject('Object Repository/Page_Home  Top 10 Best Private Universities_7aa4f6/a_apply now'))

WebUI.switchToWindowTitle('KARE')

WebUI.click(findTestObject('Object Repository/Page_KARE/a_Register'))

WebUI.setText(findTestObject('Object Repository/Page_KARE/input_Login_name'), 'Hello')

WebUI.setText(findTestObject('Object Repository/Page_KARE/input_Login_Email'), 'hello12@gmail.com')

WebUI.setText(findTestObject('Object Repository/Page_KARE/input_Zimbabwe  (263)_mobile'), '9876543210')

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_KARE/select_Select State Andaman and NicobarAndh_a90a90'), 
    '32052', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_KARE/select_Select City AgasteeswaramAlangudiAla_705298'), 
    '32140', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_KARE/select_Select School School of EngineeringS_c5e75e'), 
    '1501331', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_KARE/select_Select Program B.AB.B.AB.C.AB.ComB.Sc'), '1501341', 
    true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Page_KARE/select_Select Course Mathematics with Compu_3c2021'), 
    '1501364', true)

WebUI.setText(findTestObject('Object Repository/Page_KARE/input_Refresh_631065464'), '77566c')

WebUI.click(findTestObject('Object Repository/Page_KARE/label_I agree to receive information by sig_839872'))

WebUI.click(findTestObject('Object Repository/Page_KARE/input_Refresh_Agree'))

WebUI.click(findTestObject('Object Repository/Page_KARE/button_Register'))

WebUI.click(findTestObject('Object Repository/Page_All Application Form(s)  Kalasalingam _45fa19/a_All Application Form(s)'))

WebUI.click(findTestObject('Object Repository/Page_All Application Form(s)  Kalasalingam _45fa19/a_My Profile'))

WebUI.click(findTestObject('Object Repository/Page_Student Profile  Kalasalingam Academy _e0b74f/span_Computer Science'))

WebUI.click(findTestObject('Object Repository/Page_Student Profile  Kalasalingam Academy _e0b74f/a_Send Verification Email'))

WebUI.click(findTestObject('Object Repository/Page_Student Profile  Kalasalingam Academy _e0b74f/span_'))

WebUI.click(findTestObject('Object Repository/Page_Student Profile  Kalasalingam Academy _e0b74f/button_Cancel'))

WebUI.click(findTestObject('Object Repository/Page_Student Profile  Kalasalingam Academy _e0b74f/span_Logout'))

WebUI.switchToWindowTitle('Home · Top 10 Best Private Universities in India 2022 KARE ·')

WebUI.click(findTestObject('Object Repository/Page_Home  Top 10 Best Private Universities_7aa4f6/a_B.Sc'))

WebUI.click(findTestObject('Object Repository/Page_B.Sc.  Top 10 Best Private Universitie_867959/a_B.Sc.  Computer Science'))

WebUI.click(findTestObject('Object Repository/Page_B.Sc. - Computer Science  Top 10 Best _0bd69d/a_Download'))

WebUI.switchToWindowTitle('B.Sc. - Computer Science · Top 10 Best Private Universities in India 2022')

WebUI.click(findTestObject('Object Repository/Page_B.Sc. - Computer Science  Top 10 Best _0bd69d/img'))

WebUI.click(findTestObject('Object Repository/Page_B.Sc. - Computer Science  Top 10 Best _0bd69d/img_1'))

WebUI.click(findTestObject('Object Repository/Page_B.Sc. - Computer Science  Top 10 Best _0bd69d/img_1_2'))

WebUI.click(findTestObject('Object Repository/Page_B.Sc.  Top 10 Best Private Universitie_867959/a_Vision  Mission'))

WebUI.click(findTestObject('Object Repository/Page_Top 10 Best Private Universities in In_180711/a_Academic facilities'))

WebUI.click(findTestObject('Object Repository/Page_Academic Facility  Top 10 Best Private_c165a4/a_Department of EEE'))

WebUI.click(findTestObject('Object Repository/Page_Academic Facility  Top 10 Best Private_c165a4/button_Close'))

WebUI.click(findTestObject('Object Repository/Page_Academic Facility  Top 10 Best Private_c165a4/a_Department of Physics'))

WebUI.click(findTestObject('Object Repository/Page_Academic Facility  Top 10 Best Private_c165a4/button_Close'))

WebUI.click(findTestObject('Object Repository/Page_Academic Facility  Top 10 Best Private_c165a4/a_Placements'))

WebUI.click(findTestObject('Object Repository/Page_Placement  Top 10 Best Private Univers_6135c3/a_Internships'))

WebUI.click(findTestObject('Object Repository/Page_Internship  Top 10 Best Private Univer_47b712/img'))

WebUI.click(findTestObject('Object Repository/Page_Internship  Top 10 Best Private Univer_47b712/a_IQAC'))

WebUI.switchToWindowTitle('internal-quality-assurance-cell · Internal Quality Assurance Report')

WebUI.click(findTestObject('Object Repository/Page_internal-quality-assurance-cell  Inter_d13f15/td_Mr. A. Linguswamy (Director Admissions)K_1bb7bb'))

WebUI.click(findTestObject('Object Repository/Page_internal-quality-assurance-cell  Inter_d13f15/a_ViewDownload'))

WebUI.switchToWindowTitle('AICTE LETTER OF APPROVAL · Top 10 Best Private Universities in India 2022 %')

WebUI.click(findTestObject('Object Repository/Page_AICTE LETTER OF APPROVAL  Top 10 Best _0ade02/a_Hostels  Mess'))

WebUI.click(findTestObject('Object Repository/Page_Hostel mess  Top 10 Best Private Unive_50341e/td_Nelson Mandela Mens Hostel (MH1)'))

WebUI.click(findTestObject('Object Repository/Page_Hostel mess  Top 10 Best Private Unive_50341e/a_Download'))

WebUI.switchToWindowTitle('Internship · Top 10 Best Private Universities in India 2022')

WebUI.click(findTestObject('Object Repository/Page_Internship  Top 10 Best Private Univer_47b712/a_Sports'))

WebUI.click(findTestObject('Object Repository/Page_Sport  Top 10 Best Private Universitie_7c51ce/span_'))

WebUI.click(findTestObject('Object Repository/Page_Sport  Top 10 Best Private Universitie_7c51ce/button_National Sports Day'))

WebUI.click(findTestObject('Object Repository/Page_Sport  Top 10 Best Private Universitie_7c51ce/button_Sports Achievements'))

WebUI.click(findTestObject('Object Repository/Page_Sport  Top 10 Best Private Universitie_7c51ce/button_Swimming Pool Rules  Regulations'))

WebUI.click(findTestObject('Object Repository/Page_Sport  Top 10 Best Private Universitie_7c51ce/a_Ranking'))

WebUI.click(findTestObject('Object Repository/Page_Accrediation Ranking  Top 10 Best Priv_22d710/button_THE World University Rankings'))

WebUI.click(findTestObject('Object Repository/Page_Accrediation Ranking  Top 10 Best Priv_22d710/button_MHW Ranking'))

WebUI.click(findTestObject('Object Repository/Page_Accrediation Ranking  Top 10 Best Priv_22d710/a_Events'))

WebUI.click(findTestObject('Object Repository/Page_Events  Top 10 Best Private Universiti_0be408/span_Tel. 04563 289042_hamb-bottom'))

WebUI.click(findTestObject('Object Repository/Page_Events  Top 10 Best Private Universiti_0be408/a_Faculty Login'))

WebUI.click(findTestObject('Object Repository/Page_Faculty Login  Top 10 Best Private Uni_064a39/b_KALVI LOGIN'))

WebUI.click(findTestObject('Object Repository/Page_Faculty Login  Top 10 Best Private Uni_064a39/a_EDU LOGIN'))

WebUI.setText(findTestObject('Object Repository/Page_KARE AUTOMATION SYSTEM/input_Enter any User Name and Password_user_name'), 
    'hai')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_KARE AUTOMATION SYSTEM/input_Enter any User Name and Password_password'), 
    'VgUAfXXhEYM=')

WebUI.click(findTestObject('Object Repository/Page_KARE AUTOMATION SYSTEM/button_Sign In'))

WebUI.click(findTestObject('Object Repository/Page_KARE AUTOMATION SYSTEM/span'))

WebUI.click(findTestObject('Object Repository/Page_KARE AUTOMATION SYSTEM/button_Sign In'))

WebUI.closeBrowser()

WebUI.click(findTestObject('Object Repository/Page_Home  Top 10 Best Private Universities_7aa4f6/span_Tel. 04563 289042_hamb-top'))

WebUI.click(findTestObject('Object Repository/Page_Home  Top 10 Best Private Universities_7aa4f6/a_Parent login'))

WebUI.click(findTestObject('Object Repository/Page_Home  Top 10 Best Private Universities_7aa4f6/a_Hostel Login'))

WebUI.click(findTestObject('Object Repository/Page_Home  Top 10 Best Private Universities_7aa4f6/a_Transport login'))

WebUI.click(findTestObject('Object Repository/Page_Home  Top 10 Best Private Universities_7aa4f6/a_Alumni  - Page and login'))

WebUI.navigateToUrl('https://kalasalingam.almaconnect.com/')

WebUI.click(findTestObject('Object Repository/Page_Find Kalasalingam Madurai Alumni Membe_ff6701/div_Browse Alumni'))

WebUI.switchToWindowTitle('Find Kalasalingam Madurai Alumni Members Details Online | AlmaConnect')

WebUI.setText(findTestObject('Object Repository/Page_Find Kalasalingam Madurai Alumni Membe_ff6701/input_Login_ng-pristine ng-untouched ng-val_f6b59a'), 
    'kumar')

WebUI.sendKeys(findTestObject('Object Repository/Page_Find Kalasalingam Madurai Alumni Membe_ff6701/input_Login_ng-pristine ng-untouched ng-val_f6b59a'), 
    Keys.chord(Keys.ENTER))

WebUI.click(findTestObject('Object Repository/Page_Search  Find Kalasalingam Alumni, Stud_4f23f2/i_Course_icon-7'))

WebUI.click(findTestObject('Object Repository/Page_Search  Find Kalasalingam Alumni, Stud_4f23f2/span_Course_nicon-tick-alt'))

WebUI.click(findTestObject('Object Repository/Page_Kalasalingam Alumni Network on AlmaConnect/div_Connect_ng-scope'))

WebUI.click(findTestObject('Object Repository/Page_Kalasalingam Alumni Network on AlmaConnect/div_Course_checkbox'))

WebUI.click(findTestObject('Object Repository/Page_Kalasalingam Alumni Network on AlmaConnect/div_Connect_ng-scope'))

WebUI.click(findTestObject('Object Repository/Page_Kalasalingam Alumni Network on AlmaConnect/div_Course_dd_layer ng-scope'))

WebUI.click(findTestObject('Object Repository/Page_Kalasalingam Alumni Network on AlmaConnect/i_Graduation Year_icon-7'))

WebUI.click(findTestObject('Object Repository/Page_Kalasalingam Alumni Network on AlmaConnect/span_All Graduation Year'))

WebUI.click(findTestObject('Object Repository/Page_Kalasalingam Alumni Network on AlmaConnect/div_Connect_ng-scope'))

WebUI.doubleClick(findTestObject('Object Repository/Page_Kalasalingam Alumni Network on AlmaConnect/div_Connect_ng-scope'))

WebUI.click(findTestObject('Object Repository/Page_Kalasalingam Alumni Network on AlmaConnect/div_Course_dd_layer ng-scope'))

WebUI.click(findTestObject('Object Repository/Page_Kalasalingam Alumni Network on AlmaConnect/span_Chennai (114)'))

WebUI.click(findTestObject('Object Repository/Page_Kalasalingam Alumni Network on AlmaConnect/div_Course_dd_layer ng-scope'))

WebUI.click(findTestObject('Object Repository/Page_Kalasalingam Alumni Network on AlmaConnect/div_Reset All'))

WebUI.click(findTestObject('Object Repository/Page_Kalasalingam Alumni Network on AlmaConnect/div_Login'))

WebUI.click(findTestObject('Object Repository/Page_Kalasalingam Alumni Network on AlmaConnect/div_Connect With Google'))

WebUI.click(findTestObject('Object Repository/Page_Kalasalingam Alumni Network on AlmaConnect/div'))

WebUI.switchToWindowTitle('Home · Top 10 Best Private Universities in India 2022 KARE ·')

WebUI.click(findTestObject('Object Repository/Page_Home  Top 10 Best Private Universities_7aa4f6/a_Guest house-login'))

WebUI.click(findTestObject('Object Repository/Page_Home  Top 10 Best Private Universities_7aa4f6/a_Careers'))

WebUI.click(findTestObject('Object Repository/Page_Careers  Top 10 Best Private Universit_1b1b87/button_Apply'))

WebUI.click(findTestObject('Object Repository/Page_KARE-Recruitment Portal/a_Click Here'))

WebUI.click(findTestObject('Object Repository/Page_KARE-Recruitment Portal/input_New Registration_email_regn'))

WebUI.click(findTestObject('Object Repository/Page_KARE-Recruitment Portal/button_Submit'))

WebUI.click(findTestObject('Object Repository/Page_KARE-Recruitment Portal/button_Submit'))

WebUI.click(findTestObject('Object Repository/Page_KARE-Recruitment Portal/button_Back'))

WebUI.click(findTestObject('Object Repository/Page_KARE-Recruitment Portal/div_Login to your account   UsernamePasswor_41fc14'))

WebUI.click(findTestObject('Object Repository/Page_KARE-Recruitment Portal/a_Notification'))

WebUI.click(findTestObject('Object Repository/Page_Home  Top 10 Best Private Universities_7aa4f6/a_KARE Scholarship Portal'))

WebUI.click(findTestObject('Object Repository/Page_KARE-Scholarship Portal/button_Sign In'))

WebUI.click(findTestObject('Object Repository/Page_Home  Top 10 Best Private Universities_7aa4f6/a_e-Resource Remote Access'))

WebUI.click(findTestObject('Object Repository/Page_SHIBBOLETH IDENTITY PROVIDER/button_E - BOOKS'))

WebUI.click(findTestObject('Object Repository/Page_SHIBBOLETH IDENTITY PROVIDER/button_E - BOOKS'))

WebUI.click(findTestObject('Object Repository/Page_SHIBBOLETH IDENTITY PROVIDER/button_E - DATABASES'))

WebUI.click(findTestObject('Object Repository/Page_SHIBBOLETH IDENTITY PROVIDER/a_South Asia Archive'))

WebUI.switchToWindowTitle('Web Login Service')

WebUI.click(findTestObject('Object Repository/Page_Web Login Service/button_Login'))

WebUI.closeBrowser()

