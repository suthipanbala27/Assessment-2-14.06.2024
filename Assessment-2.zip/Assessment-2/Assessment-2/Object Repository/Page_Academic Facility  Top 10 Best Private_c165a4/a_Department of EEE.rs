<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Department of EEE</name>
   <tag></tag>
   <elementGuidId>b0babf37-7cb7-4d19-9da3-56a186f967e1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Department of EEE')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.labctn > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Department of EEE&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>6596fb43-b088-4d7d-882d-a7d72b768526</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-toggle</name>
      <type>Main</type>
      <value>modal</value>
      <webElementGuid>50c039de-7714-4958-9806-fd0ef776bb5c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-target</name>
      <type>Main</type>
      <value>#Lab1</value>
      <webElementGuid>02a2d356-1c8f-4e04-ae61-bf80e423888b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Department of EEE</value>
      <webElementGuid>7a5eefcf-f1a2-4685-baa9-7b640873276d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;wsmenucontainer&quot;]/div[@class=&quot;wrapper&quot;]/div[@class=&quot;sectiontab laboratesec&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;labslide&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-4&quot;]/div[@class=&quot;labbox&quot;]/div[@class=&quot;labctn&quot;]/a[1]</value>
      <webElementGuid>6e615cec-e61c-4a08-bb9d-a6cefe58970f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Department of EEE')]</value>
      <webElementGuid>63354734-6905-4726-b9c6-161b8d7d56dd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Laboratory Infrastructure'])[1]/following::a[1]</value>
      <webElementGuid>11930911-e8c4-43df-93ef-32ab47588eb2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='›'])[1]/following::a[1]</value>
      <webElementGuid>4c44c2d5-1d4f-436b-b91f-2ac4e2190c71</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Department of Agriculture'])[1]/preceding::a[1]</value>
      <webElementGuid>ddac4205-02d1-489e-bd01-c71e81f165da</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Department of Food Technology'])[1]/preceding::a[2]</value>
      <webElementGuid>52500f48-d854-43db-8457-85c2c707dfdc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Department of EEE']/parent::*</value>
      <webElementGuid>6a0cc27e-5657-43c9-a6ff-9fb752738204</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[9]/div/div/div/div/div/div[2]/a</value>
      <webElementGuid>8b2cd0eb-884d-446b-9d4c-06e1f2128a78</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[(text() = 'Department of EEE' or . = 'Department of EEE')]</value>
      <webElementGuid>91394c3a-b541-4620-96a1-5e4ab6f7a056</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
