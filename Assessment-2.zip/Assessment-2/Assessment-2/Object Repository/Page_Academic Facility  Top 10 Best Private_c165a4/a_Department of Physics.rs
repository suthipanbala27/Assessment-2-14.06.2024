<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Department of Physics</name>
   <tag></tag>
   <elementGuidId>07c91b98-22f4-42d6-9af1-cd9f2aa4be6a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Department of Physics')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Department of Physics&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>ac35c8fe-28cd-469a-af78-c5217fa92bd6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-toggle</name>
      <type>Main</type>
      <value>modal</value>
      <webElementGuid>40f2a56f-2c38-4864-a4a7-27b758902c82</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-target</name>
      <type>Main</type>
      <value>#Lab8</value>
      <webElementGuid>e9c13988-bc10-4286-a5e6-d24b649ab44d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Department of Physics</value>
      <webElementGuid>1c29c3c3-f70a-46f9-9705-4ddbe8999fec</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;wsmenucontainer&quot;]/div[@class=&quot;wrapper&quot;]/div[@class=&quot;sectiontab laboratesec&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;labslide&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-4&quot;]/div[@class=&quot;labbox&quot;]/div[@class=&quot;labctn&quot;]/a[1]</value>
      <webElementGuid>90eeda5e-c5a3-4c1d-a71a-4d6e27f80af3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Department of Physics')]</value>
      <webElementGuid>8b75414f-b40f-4a3a-bc55-bf429f789c20</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Department of Maths'])[1]/following::a[1]</value>
      <webElementGuid>b9c04a9b-fd51-44ee-b041-5eaf2b10db38</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Department of Forensic Science'])[1]/following::a[2]</value>
      <webElementGuid>8f07ae05-c414-4deb-b0eb-1bcecae97875</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Department of Biomedical'])[1]/preceding::a[1]</value>
      <webElementGuid>509bd294-6326-46c2-8b43-d13fefce9891</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Department of IT'])[1]/preceding::a[2]</value>
      <webElementGuid>c82f8436-8bc3-4b2c-9b92-690ae3fc6002</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Department of Physics']/parent::*</value>
      <webElementGuid>37c1ec10-c3f9-4b6c-8a2d-9734ae0248f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[2]/a</value>
      <webElementGuid>7d471952-14af-4734-9203-6c674198b0a6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[(text() = 'Department of Physics' or . = 'Department of Physics')]</value>
      <webElementGuid>3a3b604a-4ce1-4948-a2cf-101cee2c919d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
