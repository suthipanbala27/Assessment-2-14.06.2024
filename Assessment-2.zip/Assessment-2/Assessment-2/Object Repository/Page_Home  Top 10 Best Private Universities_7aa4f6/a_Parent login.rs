<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Parent login</name>
   <tag></tag>
   <elementGuidId>3ca7b510-f865-4112-80eb-d85b151fde8a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='sidebar-wrapper']/div/ul/li[3]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(3) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot; Parent login&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>cdfb7306-5e42-48ca-a16f-964d687fedd7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://kalvi.kalasalingam.ac.in/klustudentportal/students/loginManager/youLogin.jsp</value>
      <webElementGuid>389556b4-ddc7-4b4e-b753-d0115dc92597</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Parent login</value>
      <webElementGuid>0fbf1e98-fdc7-4b20-bf60-d518be30e30b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sidebar-wrapper&quot;)/div[@class=&quot;seperatoresec&quot;]/ul[@class=&quot;nav sidebar-nav&quot;]/li[3]/a[1]</value>
      <webElementGuid>5ef08c28-4a21-40a4-a782-40d5cc3c3953</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='sidebar-wrapper']/div/ul/li[3]/a</value>
      <webElementGuid>991b0cb4-4520-4b98-b21d-e86420be1f14</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Parent login')]</value>
      <webElementGuid>d91c4fd0-5cd3-40b1-804d-61ec528954fe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Student Login'])[1]/following::a[1]</value>
      <webElementGuid>cf3427ee-2e86-4183-a789-ff5e60cd9b1e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Faculty Login'])[1]/following::a[2]</value>
      <webElementGuid>3db86670-172f-401b-bd3d-35b771eaabd3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Hostel Login'])[1]/preceding::a[1]</value>
      <webElementGuid>c5bf6abe-f032-4663-8262-ead2c57b6bc8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Transport login'])[1]/preceding::a[2]</value>
      <webElementGuid>733a8943-b9d9-49fe-ad40-0ccee931dc86</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Parent login']/parent::*</value>
      <webElementGuid>b0316b4c-a0b1-40bd-958a-287a2775a05c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://kalvi.kalasalingam.ac.in/klustudentportal/students/loginManager/youLogin.jsp')]</value>
      <webElementGuid>d29ba3ef-7803-4690-a770-9dd5d60d90b7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[3]/a</value>
      <webElementGuid>91ff7d53-8476-4c12-a2aa-b4776a4a5823</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://kalvi.kalasalingam.ac.in/klustudentportal/students/loginManager/youLogin.jsp' and (text() = 'Parent login' or . = 'Parent login')]</value>
      <webElementGuid>6116fef7-fd8f-4879-86d1-d5ebeea47220</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
