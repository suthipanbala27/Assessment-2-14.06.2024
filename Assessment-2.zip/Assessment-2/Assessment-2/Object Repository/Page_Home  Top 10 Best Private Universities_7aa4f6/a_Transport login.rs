<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Transport login</name>
   <tag></tag>
   <elementGuidId>e0d052ff-b0f0-415f-9c1e-8f3adae94cb8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='sidebar-wrapper']/div/ul/li[5]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(5) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot; Transport login&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>69c4b4a1-8dcd-4c74-8c80-89134d9d9341</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://kalvi.kalasalingam.ac.in/klustudentportal/students/loginManager/youLogin.jsp</value>
      <webElementGuid>7344ec95-1ea4-44bb-803b-8b0a87488938</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Transport login</value>
      <webElementGuid>820a0e22-fa49-43b5-87bb-de9f140af65d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sidebar-wrapper&quot;)/div[@class=&quot;seperatoresec&quot;]/ul[@class=&quot;nav sidebar-nav&quot;]/li[5]/a[1]</value>
      <webElementGuid>b56574a0-e5ef-4caa-b3a6-122db7dbf194</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='sidebar-wrapper']/div/ul/li[5]/a</value>
      <webElementGuid>5a9186b3-a0dc-4d52-a462-0afd11efd867</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Transport login')]</value>
      <webElementGuid>a5e61e54-8022-43ec-bade-faaaf657c5ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Hostel Login'])[1]/following::a[1]</value>
      <webElementGuid>ef3f26d9-93f0-4889-9657-6f1bc1ef2f96</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Parent login'])[1]/following::a[2]</value>
      <webElementGuid>49362239-e2f7-4970-84c8-22b608aecece</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Guest house-login'])[1]/preceding::a[2]</value>
      <webElementGuid>91d754ba-a3fd-48a9-9f41-ecc617501344</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Transport login']/parent::*</value>
      <webElementGuid>a945d545-bf61-4237-bacb-ec776cf8f31c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://kalvi.kalasalingam.ac.in/klustudentportal/students/loginManager/youLogin.jsp')])[3]</value>
      <webElementGuid>03586bed-5eed-4168-b0f1-37914815b870</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/a</value>
      <webElementGuid>d63c5c39-3c9a-4406-a22c-bef4783e72a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://kalvi.kalasalingam.ac.in/klustudentportal/students/loginManager/youLogin.jsp' and (text() = 'Transport login' or . = 'Transport login')]</value>
      <webElementGuid>7c461c5e-1599-4a02-acdf-6c0c2b3b82ad</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
