<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_KARE Scholarship Portal</name>
   <tag></tag>
   <elementGuidId>1c869f63-84c0-4a55-a575-d5eb6c8e08a9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='sidebar-wrapper']/div/ul/li[10]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(10) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot; KARE Scholarship Portal&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>2daa6b19-07c3-4c19-b25f-4fc773557b09</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>http://scholarship.kalasalingam.ac.in/</value>
      <webElementGuid>32bee2cb-348d-4b4f-8cc0-98db3e4cd1e0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>KARE Scholarship Portal</value>
      <webElementGuid>ea5804de-cc87-4dbf-b5b2-11042e565dbd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sidebar-wrapper&quot;)/div[@class=&quot;seperatoresec&quot;]/ul[@class=&quot;nav sidebar-nav&quot;]/li[10]/a[1]</value>
      <webElementGuid>819a4534-80dc-44dd-b112-a4ef3b3b2dbf</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='sidebar-wrapper']/div/ul/li[10]/a</value>
      <webElementGuid>0153e697-fd10-4dfe-8981-ac41cb0bc80b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'KARE Scholarship Portal')]</value>
      <webElementGuid>03d7d9fe-c4e8-4279-8949-e85221b93bb4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Careers'])[1]/following::a[1]</value>
      <webElementGuid>05e6f388-283e-4dd5-b8dc-a687645ac537</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Feedback'])[1]/following::a[2]</value>
      <webElementGuid>2003c94b-1c13-43eb-8764-e0cbfb3f7371</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='e-Resource Remote Access'])[1]/preceding::a[1]</value>
      <webElementGuid>69470f3b-f9cc-4cc1-bd01-eae94f2aaf3b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RTI'])[1]/preceding::a[2]</value>
      <webElementGuid>a1370f9f-5c3a-405a-aea1-e85600341cad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='KARE Scholarship Portal']/parent::*</value>
      <webElementGuid>4ca1dedf-b5d7-4fd8-a1fa-8bc2b4279530</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[@href='http://scholarship.kalasalingam.ac.in/']</value>
      <webElementGuid>256cc97a-b6cb-4b87-9a13-48ef99bc8110</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[10]/a</value>
      <webElementGuid>03c7d34e-8f79-4477-bf15-1373924b2041</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'http://scholarship.kalasalingam.ac.in/' and (text() = 'KARE Scholarship Portal' or . = 'KARE Scholarship Portal')]</value>
      <webElementGuid>e9ebaabb-c098-424c-9fb5-f68c3c6f10de</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
