<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_e-Resource Remote Access</name>
   <tag></tag>
   <elementGuidId>e963af37-589f-4962-b2ed-73661fdc6732</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='sidebar-wrapper']/div/ul/li[11]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(11) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot; e-Resource Remote Access&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>950ec2da-5b68-46e2-9d95-6fc3860befad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>http://idp.kalasalingam.ac.in/</value>
      <webElementGuid>841b0fae-51f0-41de-9a33-d98e5c2a024e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>e-Resource Remote Access</value>
      <webElementGuid>0b2484f3-b130-4ea9-9619-8c8af5aea718</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sidebar-wrapper&quot;)/div[@class=&quot;seperatoresec&quot;]/ul[@class=&quot;nav sidebar-nav&quot;]/li[11]/a[1]</value>
      <webElementGuid>8043b485-1aaa-4150-a4a1-e696a3001dca</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='sidebar-wrapper']/div/ul/li[11]/a</value>
      <webElementGuid>804d9b66-ef80-48af-9857-b9ac5658d17f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'e-Resource Remote Access')]</value>
      <webElementGuid>70ad77ab-ce71-4fc0-91be-69a85b288199</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='KARE Scholarship Portal'])[1]/following::a[1]</value>
      <webElementGuid>b72229a6-ab31-4e71-9168-f2ffcc0b0666</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Careers'])[1]/following::a[2]</value>
      <webElementGuid>4ed5a713-4438-4657-a50e-1ff0c97701d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RTI'])[1]/preceding::a[1]</value>
      <webElementGuid>8ecefc9f-5a4b-427e-bb35-fca9ced55692</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Thesis Status'])[1]/preceding::a[2]</value>
      <webElementGuid>522972da-8500-4341-982d-a618040a9c49</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='e-Resource Remote Access']/parent::*</value>
      <webElementGuid>b2968d95-bc53-4a04-a111-2d2bd734e4d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[@href='http://idp.kalasalingam.ac.in/']</value>
      <webElementGuid>95ca8b60-0be8-423c-a27f-2bf80a9759d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[11]/a</value>
      <webElementGuid>bf132fd2-8ac2-415d-97f6-50f0ba1bb216</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'http://idp.kalasalingam.ac.in/' and (text() = 'e-Resource Remote Access' or . = 'e-Resource Remote Access')]</value>
      <webElementGuid>04558289-695c-4d9d-bddf-e50e8899f067</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
