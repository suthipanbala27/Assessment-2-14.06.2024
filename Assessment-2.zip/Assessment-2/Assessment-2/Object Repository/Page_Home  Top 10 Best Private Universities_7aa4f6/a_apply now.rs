<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_apply now</name>
   <tag></tag>
   <elementGuidId>7ebf9c73-d0b9-4a5e-9e89-33bcf4dd9f35</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'apply now')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.appnowlnk.animatelnk</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;apply now&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>41cca13c-e567-4da1-93b7-d3b674914584</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>appnowlnk animatelnk</value>
      <webElementGuid>5be12601-014d-42ad-83ec-a9a662e7c81f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://apply.kalasalingam.ac.in/</value>
      <webElementGuid>47c07553-2e99-4495-8ede-4027ac6acddc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>target</name>
      <type>Main</type>
      <value>_blank</value>
      <webElementGuid>31fb2037-da3f-4e0a-949c-fa81d0eacd85</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>apply now</value>
      <webElementGuid>1e560cfa-ceda-42dd-8020-e051a3b912b5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;wsmenucontainer&quot;]/div[@class=&quot;wrapper&quot;]/div[@class=&quot;topheader&quot;]/div[@class=&quot;largecontainer&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-6 text-right admintopsec&quot;]/a[@class=&quot;appnowlnk animatelnk&quot;]</value>
      <webElementGuid>765cb8f5-024a-4a64-ad13-324c2353b855</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'apply now')]</value>
      <webElementGuid>d7a79b85-770f-4624-b3ba-03aa5d6beb9b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact Us'])[1]/following::a[2]</value>
      <webElementGuid>69fad326-c886-4cbb-90d9-f944f6a2ef3a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='UNSDG'])[1]/following::a[3]</value>
      <webElementGuid>bab70d6b-d187-47fb-b6ef-f2e4c99d4120</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC'])[1]/preceding::a[1]</value>
      <webElementGuid>d356c586-920a-4627-b494-1bf0c280544d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SDG'])[1]/preceding::a[2]</value>
      <webElementGuid>55fefe42-5b66-4d29-8723-4c703dfdaf92</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='apply now']/parent::*</value>
      <webElementGuid>96f6426f-d1b9-40eb-855c-77050951e6c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://apply.kalasalingam.ac.in/')]</value>
      <webElementGuid>790a3e0c-7c4c-4472-80a6-0c8f072ee718</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div[2]/a</value>
      <webElementGuid>35a2fb3a-c414-45ff-a68c-7a8498cd3b71</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://apply.kalasalingam.ac.in/' and (text() = 'apply now' or . = 'apply now')]</value>
      <webElementGuid>1b3bfc30-c78f-4eb7-961c-00573c296d6b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
