<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Alumni  - Page and login</name>
   <tag></tag>
   <elementGuidId>1aeb4fc3-4951-4f3c-8360-29b8f3058018</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='sidebar-wrapper']/div/ul/li[6]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(6) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot; Alumni - Page and login&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>a2046eda-b381-4091-a910-2371ce8a7223</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://kalasalingam.almaconnect.com/</value>
      <webElementGuid>2b1a598e-da09-408e-aee8-645c0e8affda</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Alumni  - Page and login</value>
      <webElementGuid>1be46658-b0c4-468d-a736-817f095e9108</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sidebar-wrapper&quot;)/div[@class=&quot;seperatoresec&quot;]/ul[@class=&quot;nav sidebar-nav&quot;]/li[6]/a[1]</value>
      <webElementGuid>69fcc5c7-258e-4207-a206-bc22f3785939</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='sidebar-wrapper']/div/ul/li[6]/a</value>
      <webElementGuid>22056756-d991-42cd-acc7-41aef4d49f56</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Alumni  - Page and login')]</value>
      <webElementGuid>8f044aa9-da80-4c99-b291-2fceb413ecde</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Transport login'])[1]/following::a[1]</value>
      <webElementGuid>fb118dc9-d320-4ae2-a3af-4d639c4403b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Hostel Login'])[1]/following::a[2]</value>
      <webElementGuid>9f454024-610f-4733-9615-575551d419d8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Guest house-login'])[1]/preceding::a[1]</value>
      <webElementGuid>42cdcc8a-8fc3-4dc0-abff-2696ddb36ba1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Feedback'])[1]/preceding::a[2]</value>
      <webElementGuid>6cd8bd78-b3d6-4b3d-9884-450b96b9bf65</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://kalasalingam.almaconnect.com/')]</value>
      <webElementGuid>7452d7a0-a480-4971-92df-76c4c852b4df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[6]/a</value>
      <webElementGuid>ffabf533-a05f-4242-8dc5-9801a59443fc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://kalasalingam.almaconnect.com/' and (text() = 'Alumni  - Page and login' or . = 'Alumni  - Page and login')]</value>
      <webElementGuid>c6090f01-4cbc-46cb-b6a5-61c8995cccf0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
