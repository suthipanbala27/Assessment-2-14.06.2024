<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Hostels  Mess</name>
   <tag></tag>
   <elementGuidId>00d2b18f-739b-41cd-ae70-4ba26303b0ee</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Hostels &amp; Mess')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Hostels &amp; Mess&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>172f50f6-ed7d-4f70-9fc9-8334f0cfc88a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://kalasalingam.ac.in/hostel-mess</value>
      <webElementGuid>c531a956-442f-45d5-929a-46358acf8785</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Hostels &amp; Mess</value>
      <webElementGuid>23604953-5ae4-42e5-88db-c6043135de2d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;wsmenucontainer&quot;]/div[@class=&quot;wrapper&quot;]/div[@class=&quot;middlediv wsmenucontainer clearfix&quot;]/div[@class=&quot;header sticky stick-me not-sticking&quot;]/div[@class=&quot;largecontainer&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-9 navigation text-right&quot;]/nav[@class=&quot;wsmenu clearfix&quot;]/ul[@class=&quot;wsmenu-list&quot;]/li[4]/ul[@class=&quot;row sub-menu twocolum&quot;]/div[@class=&quot;innermenuitem&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-3&quot;]/ul[1]/li[1]/a[1]</value>
      <webElementGuid>269b3067-557f-4eab-9154-7570f88c0ef9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Hostels &amp; Mess')]</value>
      <webElementGuid>1122a11a-030c-4560-a6d0-0e31c7aecbbe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Events'])[1]/following::a[1]</value>
      <webElementGuid>e6a59e15-cead-46a8-aecd-06983b2f6273</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Transport'])[1]/following::a[2]</value>
      <webElementGuid>e087e9d0-072b-4bc0-93e7-a531f42674a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sports'])[1]/preceding::a[1]</value>
      <webElementGuid>abb028be-9108-4c26-a185-48dba7cfff5b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Student affairs'])[1]/preceding::a[2]</value>
      <webElementGuid>7aa64be9-7cd2-495e-a2ac-33902766acf4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Hostels &amp; Mess']/parent::*</value>
      <webElementGuid>0b687983-6757-4935-b8a9-74ad63f57c05</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://kalasalingam.ac.in/hostel-mess')]</value>
      <webElementGuid>82937542-76ab-4cd2-9c47-45ed7b8b7b8e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[4]/ul/div/div/div[3]/ul/li/a</value>
      <webElementGuid>7bf9f237-a786-400e-b655-6e6bb9d6fb64</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://kalasalingam.ac.in/hostel-mess' and (text() = 'Hostels &amp; Mess' or . = 'Hostels &amp; Mess')]</value>
      <webElementGuid>650d8cef-95e2-4833-bc46-72442b827cf6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
