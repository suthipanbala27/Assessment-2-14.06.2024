<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Reset All</name>
   <tag></tag>
   <elementGuidId>b91af5e7-dc1b-4927-b1e7-40f91f065994</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//html[@id='filter-page']/body/div[3]/div[2]/div/div/div/div[2]/div/div/div[4]/div/div[2]/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.ng-scope > div > div.ng-scope > div.text_heading</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Reset All&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>4b7ddc8a-0e71-464d-98bb-b0e741132d77</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text_heading</value>
      <webElementGuid>14cd0645-fd64-40da-af6d-19fedfbf66cf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-click</name>
      <type>Main</type>
      <value>resetFilters()</value>
      <webElementGuid>bed59819-a4ff-4b8b-af2e-1a04abe979b9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    Reset All
  </value>
      <webElementGuid>e8e69747-2164-45dd-ab6d-d8864be1d198</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;filter-page&quot;)/body[@class=&quot;body&quot;]/div[3]/div[@class=&quot;page_layout&quot;]/div[@class=&quot;main_column&quot;]/div[@class=&quot;js_directory_filter ng-scope&quot;]/div[1]/div[@class=&quot;inner_main_column&quot;]/div[@class=&quot;js_dir_users_list inner_sec_column_copy_sibling ng-scope&quot;]/div[@class=&quot;box-shadow-content&quot;]/div[@class=&quot;ng-scope&quot;]/div[1]/div[@class=&quot;ng-scope&quot;]/div[@class=&quot;text_heading&quot;]</value>
      <webElementGuid>6e76db88-845f-4d38-be34-8a2d9e834464</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//html[@id='filter-page']/body/div[3]/div[2]/div/div/div/div[2]/div/div/div[4]/div/div[2]/div</value>
      <webElementGuid>fb1d4475-c944-4fcd-ac51-2aafc62e0e28</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='All Filters'])[1]/following::div[2]</value>
      <webElementGuid>650aeebb-2815-486e-99c1-65e3d78bd593</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='(1)'])[1]/following::div[6]</value>
      <webElementGuid>0ee4d545-5acd-450b-a518-bcb28d72e1e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='KUMARESAN.S'])[1]/preceding::div[9]</value>
      <webElementGuid>fe35ddc9-0963-4ebb-8739-092b02969814</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Reset All']/parent::*</value>
      <webElementGuid>155e398f-0a76-441a-853f-560365826a29</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div[2]/div</value>
      <webElementGuid>6dc81641-95eb-4ec0-b431-40386fe6b53d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
    Reset All
  ' or . = '
    Reset All
  ')]</value>
      <webElementGuid>dc7aefd9-31d7-4260-a805-c5b741886fbd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
