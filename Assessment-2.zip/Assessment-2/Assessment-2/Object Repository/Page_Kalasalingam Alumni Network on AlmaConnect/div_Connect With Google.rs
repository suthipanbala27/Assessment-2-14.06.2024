<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Connect With Google</name>
   <tag></tag>
   <elementGuidId>fb03b677-738c-42f5-9123-3c90a555fbe9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//html[@id='filter-page']/body/div/div/div/div/div[3]/div/div/div/div/div/div[3]/div[2]/div/div/div/div[2]/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.text_title_small.ellipsis.ng-binding</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Connect With Google&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>a7d9581f-47d8-4d16-9933-01b265ede31a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text_title_small ellipsis ng-binding</value>
      <webElementGuid>bd97c07c-e60c-4462-bba6-23f7f5d04f5b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        Connect With Google
      </value>
      <webElementGuid>4c147785-ab6f-4435-97ba-775bc6e4e325</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;filter-page&quot;)/body[@class=&quot;body&quot;]/div[@class=&quot;js_login_popup ng-scope&quot;]/div[@class=&quot;ng-isolate-scope&quot;]/div[@class=&quot;ng-scope&quot;]/div[1]/div[3]/div[1]/div[1]/div[@class=&quot;ng-scope&quot;]/div[1]/div[1]/div[@class=&quot;ng-scope&quot;]/div[2]/div[@class=&quot;ng-isolate-scope&quot;]/div[1]/div[@class=&quot;ac_google_button&quot;]/div[@class=&quot;p_text ng-scope&quot;]/div[@class=&quot;text_title_small ellipsis ng-binding&quot;]</value>
      <webElementGuid>558e3b80-d148-4a7c-8475-161d47af903e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//html[@id='filter-page']/body/div/div/div/div/div[3]/div/div/div/div/div/div[3]/div[2]/div/div/div/div[2]/div</value>
      <webElementGuid>c79522e7-5027-4021-8cc4-7017b2b1bb54</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Connect With Linkedin'])[1]/following::div[7]</value>
      <webElementGuid>dc923bd6-9c22-4c52-ad9a-6aaa66d09f3c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)=', Students &amp; Faculty'])[1]/following::div[15]</value>
      <webElementGuid>c572ecc5-6ecb-4bbd-97b8-c32e1cacc3eb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign up with Email'])[1]/preceding::div[2]</value>
      <webElementGuid>158bdb06-8d09-4b0a-b78a-40721305f171</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login with One Time Password (OTP)'])[1]/preceding::div[9]</value>
      <webElementGuid>ab8c1e1b-216e-4355-867d-91d6ade9ebc6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Connect With Google']/parent::*</value>
      <webElementGuid>0d77a3bc-ca1f-4bc7-b9a8-4f52cf385bac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div[2]/div</value>
      <webElementGuid>781e7781-8e6b-4bf4-ba04-3959b21cdbf8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
        Connect With Google
      ' or . = '
        Connect With Google
      ')]</value>
      <webElementGuid>0efb60d3-4dfb-4fda-acc0-dedef91c9f30</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
