<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Chennai (114)</name>
   <tag></tag>
   <elementGuidId>e78c8a51-3d40-4186-a829-fb674172478f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//html[@id='filter-page']/body/div[3]/div[2]/div/div/div/div[2]/div/div/div[4]/div/div/div[3]/div/div[2]/div/div[2]/div/div[2]/div/div/div/label/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.ng-scope > div.ng-scope > div.ng-isolate-scope > div.ac_input_checkbox > label > span.label.ng-binding</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Chennai (114)&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>c7da4d74-e8e7-4c1f-895d-61ea921ecde9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-show</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>b80644da-5609-4b77-8a2b-3be2bd7bdb05</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>label ng-binding</value>
      <webElementGuid>8d208b16-e64c-4490-b288-3e54fd883b15</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
      Chennai (114)
    </value>
      <webElementGuid>66677edb-34d7-4ad2-b65e-973f15006c6c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;filter-page&quot;)/body[@class=&quot;body&quot;]/div[3]/div[@class=&quot;page_layout&quot;]/div[@class=&quot;main_column&quot;]/div[@class=&quot;js_directory_filter ng-scope&quot;]/div[1]/div[@class=&quot;inner_main_column&quot;]/div[@class=&quot;js_dir_users_list inner_sec_column_copy_sibling ng-scope&quot;]/div[@class=&quot;box-shadow-content&quot;]/div[@class=&quot;ng-scope&quot;]/div[1]/div[1]/div[@class=&quot;ng-scope&quot;]/div[@class=&quot;ng-scope&quot;]/div[@class=&quot;ng-isolate-scope&quot;]/div[@class=&quot;ac_dropdown ng-scope&quot;]/div[2]/div[@class=&quot;ng-scope&quot;]/div[@class=&quot;ng-scope&quot;]/div[@class=&quot;ng-scope&quot;]/div[@class=&quot;ng-isolate-scope&quot;]/div[@class=&quot;ac_input_checkbox&quot;]/label[1]/span[@class=&quot;label ng-binding&quot;]</value>
      <webElementGuid>6d45fc79-ba71-481c-8a91-60cc286a3727</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//html[@id='filter-page']/body/div[3]/div[2]/div/div/div/div[2]/div/div/div[4]/div/div/div[3]/div/div[2]/div/div[2]/div/div[2]/div/div/div/label/span</value>
      <webElementGuid>4fe0f5e1-3c30-4fd7-93ce-8fbc97b28c16</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='All Location'])[1]/following::span[2]</value>
      <webElementGuid>af86d437-fd5d-4971-836c-6fc2b2232037</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Location'])[1]/following::span[4]</value>
      <webElementGuid>b581dd41-5593-4a21-8c89-cb8026b886a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Bangalore (56)'])[1]/preceding::span[2]</value>
      <webElementGuid>fb617183-6d0d-464e-a92d-0982c68f6596</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Madurai (56)'])[1]/preceding::span[4]</value>
      <webElementGuid>a19c2579-2905-41c4-9c24-82ac06f3ccc1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Chennai (114)']/parent::*</value>
      <webElementGuid>8e6f230f-cd4b-4971-8ba3-36d85fc6a7f2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[2]/div/div[2]/div/div/div/label/span</value>
      <webElementGuid>2201676d-4b14-4962-8464-c9a858d0f56a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = '
      Chennai (114)
    ' or . = '
      Chennai (114)
    ')]</value>
      <webElementGuid>1ddf2ab4-c1bb-4b79-91e5-af6e2f7ced96</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
