<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_Nelson Mandela Mens Hostel (MH1)</name>
   <tag></tag>
   <elementGuidId>b4fbb942-d8a1-4d5b-9aee-1ff3e4680c88</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Name of the Hostel (Boys Hostel)'])[1]/following::td[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>td:nth-of-type(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Nelson Mandela Men’s Hostel (MH1)&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>131e492e-9949-44a6-a18a-eb369f41faf1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Nelson Mandela Men’s Hostel (MH1)</value>
      <webElementGuid>d956448d-6822-4c25-b56b-8088cb9c32ca</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;wsmenucontainer&quot;]/div[@class=&quot;wrapper&quot;]/div[@class=&quot;sectiontab aboutgrp facultybg hostelcar&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;hosteltable&quot;]/table[1]/tbody[1]/tr[1]/td[2]</value>
      <webElementGuid>a733223c-bb36-4a39-a89a-b1bdc443d9ac</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Name of the Hostel (Boys Hostel)'])[1]/following::td[2]</value>
      <webElementGuid>dcea6c0b-f740-41dc-aa33-d17bb848e602</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='S.No'])[1]/following::td[2]</value>
      <webElementGuid>e1c62052-4de3-445e-99b0-310b4d23a5be</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Bhagat Singh Men’s Hostel (MH2)'])[1]/preceding::td[2]</value>
      <webElementGuid>51d3e7c3-99f5-4343-b17b-f91fbe102c36</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dr.S.Radhakrishnan Men’s Hostel (MH3)'])[1]/preceding::td[4]</value>
      <webElementGuid>bf5c75a5-be11-456a-9f8a-4de27ff29cb7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Nelson Mandela Men’s Hostel (MH1)']/parent::*</value>
      <webElementGuid>bf018fc9-a92a-408f-9e65-04104c89c15a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td[2]</value>
      <webElementGuid>947de007-0b26-48b2-aac8-8e1338897de2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'Nelson Mandela Men’s Hostel (MH1)' or . = 'Nelson Mandela Men’s Hostel (MH1)')]</value>
      <webElementGuid>7934f67b-1152-460c-a50b-11ed2eab299d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
