<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Browse Alumni</name>
   <tag></tag>
   <elementGuidId>e539472a-9787-4efb-b2a0-dc4794e1d104</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//html[@id='index-page']/body/div[2]/div/div/div/div/div/div/div/div/div/div[5]/a/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.ac_sec_button_small.ng-scope</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Browse Alumni&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>dcb919ff-3e72-468f-a8ae-7587f69f01c3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ac_sec_button_small ng-scope</value>
      <webElementGuid>e47d89ba-e876-4854-bd50-93b02794fe8c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-custom-if</name>
      <type>Main</type>
      <value>currentInstitute.id &amp;&amp; !currentInstitute.bossy_client &amp;&amp; (currentInstitute.type != 'Institution::Company')</value>
      <webElementGuid>19fd2d5b-6aac-495a-8689-ffa689c4a5a7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    Browse Alumni
  </value>
      <webElementGuid>90c3c3c6-c7aa-4d7a-bc56-faf8ca1b313a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;index-page&quot;)/body[@class=&quot;body&quot;]/div[@class=&quot;page_layout&quot;]/div[@class=&quot;js_ac_signup ng-scope&quot;]/div[@class=&quot;ng-scope&quot;]/div[@class=&quot;ng-scope&quot;]/div[@class=&quot;landing_signup_box&quot;]/div[@class=&quot;landing_signup_box_bg&quot;]/div[@class=&quot;landing_signup_box_bg_inner&quot;]/div[1]/div[1]/div[@class=&quot;ng-scope&quot;]/div[5]/a[1]/div[@class=&quot;ac_sec_button_small ng-scope&quot;]</value>
      <webElementGuid>fd6ff8a5-3682-463b-a948-b3ea8ecbacbf</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//html[@id='index-page']/body/div[2]/div/div/div/div/div/div/div/div/div/div[5]/a/div</value>
      <webElementGuid>6c3b12e2-e016-48de-b9f8-7b86206d21ee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login with One Time Password (OTP)'])[1]/following::div[1]</value>
      <webElementGuid>2665197a-9c71-4408-9969-62200df695c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign up with Email'])[1]/following::div[5]</value>
      <webElementGuid>97501d68-ff55-483d-9f65-d3e57293c9a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='terms and conditions'])[1]/preceding::div[2]</value>
      <webElementGuid>ea49938d-83c7-47b0-8791-c03958d9b908</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Browse Alumni']/parent::*</value>
      <webElementGuid>fed23be5-782d-42d9-aea3-b99e4e084690</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/a/div</value>
      <webElementGuid>8a9a3b24-ecaf-49b0-8188-6a6e580009aa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
    Browse Alumni
  ' or . = '
    Browse Alumni
  ')]</value>
      <webElementGuid>acfd738b-763c-418c-8fac-42fbe61f6a4d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
