<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_Mr. A. Linguswamy (Director Admissions)K_1bb7bb</name>
   <tag></tag>
   <elementGuidId>ff2f31ee-c8d4-42d7-851b-ee81a83db997</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Member'])[10]/following::td[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(15) > td:nth-of-type(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;Mr. A. Linguswamy (Director Admissions) Kalasalingam Academy of Research and Education&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>014291d9-88cb-46db-9c98-be5c735d6fd5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Mr. A. Linguswamy (Director Admissions)Kalasalingam Academy of Research and Education</value>
      <webElementGuid>a53baddf-6c08-437e-93a8-d34b59c23a0c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;wsmenucontainer&quot;]/div[@class=&quot;wrapper&quot;]/div[@class=&quot;sectiontab aboutgrp facultybg hostelcar majresctn iqasmembre scropadd&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;hosteltable&quot;]/table[1]/tbody[1]/tr[15]/td[2]</value>
      <webElementGuid>b0096cf6-9cd1-491b-b6c7-6620aba2bd91</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Member'])[10]/following::td[2]</value>
      <webElementGuid>aeb854bb-a52c-4602-9747-35cf4c688cc7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kalasalingam Academy of Research and Education'])[11]/following::td[3]</value>
      <webElementGuid>97fe9df1-a192-4275-9572-aa3d370f254d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Member'])[11]/preceding::td[1]</value>
      <webElementGuid>8ddefc39-37be-4f7c-a47a-4fe55aab4330</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Mr. A. Linguswamy (Director Admissions)']/parent::*</value>
      <webElementGuid>a465eb68-3dd8-4b61-b27b-7669d32dc575</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[15]/td[2]</value>
      <webElementGuid>382819ea-2651-4473-8955-597584c8372d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'Mr. A. Linguswamy (Director Admissions)Kalasalingam Academy of Research and Education' or . = 'Mr. A. Linguswamy (Director Admissions)Kalasalingam Academy of Research and Education')]</value>
      <webElementGuid>8b271dcf-ca50-4876-b7cf-e989f98aa170</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
