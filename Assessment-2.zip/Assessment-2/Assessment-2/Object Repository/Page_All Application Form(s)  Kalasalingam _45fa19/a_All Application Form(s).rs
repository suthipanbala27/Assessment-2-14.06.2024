<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_All Application Form(s)</name>
   <tag></tag>
   <elementGuidId>ccab769f-dc7e-4b97-a5df-22cddd7fdeba</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[1]/following::a[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.active > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;All Application Form(s)&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>35b61e05-9d59-424f-a2f8-08d2eaee787c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://apply.kalasalingam.ac.in/all-application-form</value>
      <webElementGuid>5bb99202-678f-4391-a97d-5cb284097775</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> All Application Form(s)</value>
      <webElementGuid>1c86f137-d42a-44d4-8253-063920a0c895</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;nD kalasalingamacademyofresearchandeducation&quot;]/div[@class=&quot;main-content fadeIn&quot;]/div[@class=&quot;container-fluid&quot;]/div[@class=&quot;row display-flex&quot;]/div[@class=&quot;col-sm-3 col-md-3 col-lg-2 sidebar&quot;]/ul[@class=&quot;nav nav-sidebar&quot;]/li[@class=&quot;active&quot;]/a[1]</value>
      <webElementGuid>dc7702bd-9253-4624-983b-a27fef2098ad</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[1]/following::a[1]</value>
      <webElementGuid>cd84c2c8-de82-4ab4-8ca3-8a416c60e1a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='UG and PG Regular Application Form'])[1]/preceding::a[1]</value>
      <webElementGuid>37790be5-7aad-4d9b-9b69-4f44099a21e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://apply.kalasalingam.ac.in/all-application-form')])[2]</value>
      <webElementGuid>1894ee5f-390d-420b-a234-b241eef512c5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul/li[2]/a</value>
      <webElementGuid>9e5b9788-b81f-4f8d-84de-3ea91a15d662</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://apply.kalasalingam.ac.in/all-application-form' and (text() = ' All Application Form(s)' or . = ' All Application Form(s)')]</value>
      <webElementGuid>bd0e2adf-58c1-4e94-83f5-c82d594f3de9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
