<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_My Profile</name>
   <tag></tag>
   <elementGuidId>f5276419-a529-4eb1-978a-cf1223a84fd7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='PhD Application form'])[1]/following::a[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.nav.nav-sidebar > li:nth-of-type(3) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;My Profile&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>a2d08ee7-fbde-4a40-a7aa-88c56638e9c8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://apply.kalasalingam.ac.in/profile</value>
      <webElementGuid>0d95b6f3-1139-494b-9d45-55c9812a275e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>My Profile</value>
      <webElementGuid>359dffe9-5dd0-4d15-a9a0-25bdd652c96c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;nD kalasalingamacademyofresearchandeducation&quot;]/div[@class=&quot;main-content fadeIn&quot;]/div[@class=&quot;container-fluid&quot;]/div[@class=&quot;row display-flex&quot;]/div[@class=&quot;col-sm-3 col-md-3 col-lg-2 sidebar&quot;]/ul[@class=&quot;nav nav-sidebar&quot;]/li[3]/a[1]</value>
      <webElementGuid>fcbacab2-640c-4caf-88cc-3c15f172ce9e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PhD Application form'])[1]/following::a[1]</value>
      <webElementGuid>6e31af90-aaf8-4cac-ac3e-fa5367b13022</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Online and Distance Learning Application Form'])[1]/following::a[2]</value>
      <webElementGuid>91ed6b2f-95ff-4edc-b9a0-88a1f6c593d5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='My Queries'])[1]/preceding::a[1]</value>
      <webElementGuid>d7bc5795-9786-4894-95eb-d6940c10080a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://apply.kalasalingam.ac.in/profile')])[2]</value>
      <webElementGuid>19e0348b-b4fe-4018-bd4b-280ef69522e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul/li[3]/a</value>
      <webElementGuid>21dc0c12-c0a0-4263-83db-7f351db77a7d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://apply.kalasalingam.ac.in/profile' and (text() = 'My Profile' or . = 'My Profile')]</value>
      <webElementGuid>528072b7-d543-46c9-8aa0-58f5d3c485d1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
