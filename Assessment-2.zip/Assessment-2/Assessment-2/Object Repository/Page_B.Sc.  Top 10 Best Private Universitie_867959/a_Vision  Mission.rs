<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Vision  Mission</name>
   <tag></tag>
   <elementGuidId>835e1d40-f010-4d96-bf56-2e40c35ca8c4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Vision &amp; Mission')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-sm-3 > ul > li:nth-of-type(2) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Vision &amp; Mission&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>ab9be141-1d07-4dc3-aa19-a919fbe0aca2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://kalasalingam.ac.in/about-us#vision</value>
      <webElementGuid>c04bd911-8b76-4b66-a401-5b2e8bf0eed8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Vision &amp; Mission</value>
      <webElementGuid>60af727b-b6fd-457a-997f-14b46cfd7238</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;wsmenucontainer&quot;]/div[@class=&quot;wrapper&quot;]/div[@class=&quot;middlediv wsmenucontainer clearfix&quot;]/div[@class=&quot;header sticky stick-me not-sticking&quot;]/div[@class=&quot;largecontainer&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-9 navigation text-right&quot;]/nav[@class=&quot;wsmenu clearfix&quot;]/ul[@class=&quot;wsmenu-list&quot;]/li[1]/ul[@class=&quot;row sub-menu twocolum&quot;]/div[@class=&quot;innermenuitem&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-3&quot;]/ul[1]/li[2]/a[1]</value>
      <webElementGuid>cf0ad834-e767-48ba-8064-1de9adf68453</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Vision &amp; Mission')]</value>
      <webElementGuid>20674096-ab87-4881-9365-b59da73ede61</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Overview'])[1]/following::a[1]</value>
      <webElementGuid>40b39b27-2126-4476-b840-bd12b6590ed5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About Us'])[1]/following::a[2]</value>
      <webElementGuid>bc91d559-11e7-450e-83bf-79d1fa380074</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Governance'])[1]/preceding::a[1]</value>
      <webElementGuid>95e81b3f-981a-45d0-943c-2d3d44365cd8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Leadership'])[1]/preceding::a[2]</value>
      <webElementGuid>444a6e25-8542-4823-8840-8253ca2ddddd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Vision &amp; Mission']/parent::*</value>
      <webElementGuid>3f83e2b7-a977-41cf-8eda-5795dde8c364</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://kalasalingam.ac.in/about-us#vision')]</value>
      <webElementGuid>01f88861-c003-47ca-b3bd-90248c41e0f6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/ul/li[2]/a</value>
      <webElementGuid>9c2af53a-0ca2-4a95-a92a-f2490f3cd98d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://kalasalingam.ac.in/about-us#vision' and (text() = 'Vision &amp; Mission' or . = 'Vision &amp; Mission')]</value>
      <webElementGuid>3cc280f6-b136-4be6-b486-4df0c354869e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
