<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_B.Sc.  Computer Science</name>
   <tag></tag>
   <elementGuidId>7b52e476-a686-4fea-abad-33db96dcf530</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'B.Sc. – Computer Science')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.arrowlst > li:nth-of-type(4) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;B.Sc. – Computer Science&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>8bb9bc8d-cbb5-4af5-b245-dab6df4be3af</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>b-sc-computer-science/</value>
      <webElementGuid>101f857a-ae79-4f6c-88f9-8359a124325a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>B.Sc. – Computer Science</value>
      <webElementGuid>1043029e-e9ab-4c90-9778-fc6fe32b0b9b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;wsmenucontainer&quot;]/div[@class=&quot;wrapper&quot;]/div[@class=&quot;sectiontab darkgraybg whykalas&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-6&quot;]/ul[@class=&quot;arrowlst&quot;]/li[4]/a[1]</value>
      <webElementGuid>c31ff193-56a4-47d2-9bed-9d94b28055fa</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'B.Sc. – Computer Science')]</value>
      <webElementGuid>b49f4518-d46e-4cba-9481-f91ccfb1ace7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='B.Sc. – Chemistry'])[1]/following::a[1]</value>
      <webElementGuid>b477bb87-3946-48cc-9a6f-0dbcd4f27816</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='B.Sc. – Catering and Hotel Management'])[1]/following::a[2]</value>
      <webElementGuid>92297add-a142-4b8c-84a8-49dd4d9efaa2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='B.Sc. – Forensic Science'])[1]/preceding::a[1]</value>
      <webElementGuid>59c25626-b5dc-45ed-a598-9403b09c0522</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='B.Sc.(Hons) – Horticulture'])[1]/preceding::a[2]</value>
      <webElementGuid>eaac9fcb-6226-4f3e-aed4-31e431da5a21</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='B.Sc. – Computer Science']/parent::*</value>
      <webElementGuid>498286ba-48ec-48af-8cc8-eee59683967f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'b-sc-computer-science/')]</value>
      <webElementGuid>9ebe3f88-0aae-4cbc-824c-124645a4936e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/ul/li[4]/a</value>
      <webElementGuid>80f04434-f55b-4d22-9b50-9bbedb3349ec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'b-sc-computer-science/' and (text() = 'B.Sc. – Computer Science' or . = 'B.Sc. – Computer Science')]</value>
      <webElementGuid>9189c869-9018-412f-8f84-2c01aee11353</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
