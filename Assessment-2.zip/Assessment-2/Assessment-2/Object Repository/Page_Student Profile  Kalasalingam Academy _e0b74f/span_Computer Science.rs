<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Computer Science</name>
   <tag></tag>
   <elementGuidId>07fb90cf-c26d-4c62-99d6-06dc77326aba</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='ProfileForm']/div[2]/div[10]/div/div/div/p/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.SumoSelect.sumo_specialization_id > p.CaptionCont.SelectBox.search > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;Computer Science&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>5733d5ad-75bf-45dd-8ca4-dfb0e8e202f1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Computer Science</value>
      <webElementGuid>9afac4d0-f8a3-4294-80c2-56ccb36b3a4c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ProfileForm&quot;)/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12 profile_specialization_id_div&quot;]/div[@class=&quot;form-group&quot;]/div[@class=&quot;field-container&quot;]/div[@class=&quot;SumoSelect sumo_specialization_id&quot;]/p[@class=&quot;CaptionCont SelectBox search&quot;]/span[1]</value>
      <webElementGuid>ffd6cb54-8cad-422b-b811-56d92a7f8d17</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='ProfileForm']/div[2]/div[10]/div/div/div/p/span</value>
      <webElementGuid>43ed840d-e29f-41f1-9511-36015bf57cb1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='*'])[9]/following::span[1]</value>
      <webElementGuid>137530c5-070b-4328-80c1-b6c4311530fc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Select Course *'])[2]/preceding::span[1]</value>
      <webElementGuid>38069624-56dc-41f3-83cb-1d18a6c43318</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mathematics with Computer Applications'])[2]/preceding::span[1]</value>
      <webElementGuid>2c5df910-7ef6-409a-b059-d715b0581a55</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[10]/div/div/div/p/span</value>
      <webElementGuid>d0af0d2c-2790-4553-b8b0-f611db1e04eb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = ' Computer Science' or . = ' Computer Science')]</value>
      <webElementGuid>7dc9a9dc-f2eb-4bb4-9669-5e34f8faadcd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
