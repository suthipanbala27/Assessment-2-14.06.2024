<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_EDU LOGIN</name>
   <tag></tag>
   <elementGuidId>ae1050c8-6d18-4c37-b220-f292a57fe671</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='KALVI LOGIN'])[1]/following::a[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;EDU LOGIN&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>4deebf8d-95b0-475c-80c7-effb044f6a4b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://edu.kalasalingam.ac.in/</value>
      <webElementGuid>ee73e932-1316-46dc-8a7a-6c4862905ee7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>EDU LOGIN</value>
      <webElementGuid>5a742b4d-4af0-4f0f-9aaa-62aa5167e3c7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;wsmenucontainer&quot;]/div[@class=&quot;wrapper&quot;]/div[@class=&quot;whycare padd65&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-4&quot;]/div[@class=&quot;inlinediv&quot;]/a[1]</value>
      <webElementGuid>9e75aefb-0f73-49f5-b575-f0ea109c9d82</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='KALVI LOGIN'])[1]/following::a[1]</value>
      <webElementGuid>4ab21f3c-17c8-4b40-b1ad-e25d585e1d66</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Faculty Login'])[3]/following::a[2]</value>
      <webElementGuid>05dbc82e-6501-4a77-ab55-f557f3b75169</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='KALVI LMS LOGIN'])[1]/preceding::a[1]</value>
      <webElementGuid>449a60b5-c5c7-4b0d-a4f1-644da196d75b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://edu.kalasalingam.ac.in/')])[3]</value>
      <webElementGuid>a98d24b7-04a0-4365-b654-416146fa607e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/div/div[2]/div/a</value>
      <webElementGuid>11207ae8-eb3d-4e93-8084-12406ee2543d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://edu.kalasalingam.ac.in/' and (text() = 'EDU LOGIN' or . = 'EDU LOGIN')]</value>
      <webElementGuid>32c5741b-b656-4330-88be-c58cba2f5442</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
