<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>b_KALVI LOGIN</name>
   <tag></tag>
   <elementGuidId>787867e2-9cc4-4d69-83c5-652449332670</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Faculty Login'])[3]/following::b[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>b</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;KALVI LOGIN&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>b</value>
      <webElementGuid>9ceb41fd-ebab-420e-a9d3-614582c4a89e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>KALVI LOGIN</value>
      <webElementGuid>7261ca75-b212-4de1-80af-d2d505a4cb08</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;wsmenucontainer&quot;]/div[@class=&quot;wrapper&quot;]/div[@class=&quot;whycare padd65&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-4&quot;]/div[@class=&quot;inlinediv&quot;]/a[1]/b[1]</value>
      <webElementGuid>daf6d253-8b3a-4d29-8f6e-cb34ec3f6d4e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Faculty Login'])[3]/following::b[1]</value>
      <webElementGuid>9983932a-71bc-40d7-848f-d1dbeff79bac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Faculty Login'])[2]/following::b[1]</value>
      <webElementGuid>d7d824f8-0b6b-47fd-bcf4-87c414cace91</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='EDU LOGIN'])[1]/preceding::b[1]</value>
      <webElementGuid>4f5a25e1-60e6-41b6-80f5-abd37b36a6ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='KALVI LMS LOGIN'])[1]/preceding::b[2]</value>
      <webElementGuid>4fd5822a-514b-44be-9436-1f16b70b1e4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='KALVI LOGIN']/parent::*</value>
      <webElementGuid>fa99efdd-1831-4f2a-b458-1cb7beea7efb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//b</value>
      <webElementGuid>bb4b2957-e4bc-4550-96d1-0dfaaa85f050</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//b[(text() = 'KALVI LOGIN' or . = 'KALVI LOGIN')]</value>
      <webElementGuid>96c046e0-9787-4f78-a443-cb5ebc83d5b7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
