<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Login to your account   UsernamePasswor_41fc14</name>
   <tag></tag>
   <elementGuidId>28988c39-d5bc-4ab4-b265-25a3b47bae2f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.content</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div >> internal:has-text=&quot;Login to your account Username Password Remember me Login New Registration? Clic&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>769448e1-0ba1-4316-9060-1d3fea953d04</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>content</value>
      <webElementGuid>2dc41f16-59a9-4f6e-80c4-703e6265947f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	
	
		Login to your account
		  	 
		
			
			Username
			
				
				
			
		
		
			Password
			
				
				
			
		
		
			
			 Remember me 
			
			
			Login 
			
			
		
	
		
				New Registration?
				
					 
					Click Here 
					For Registration.
				
		
		
				Forgot your password ?
				
					
					Click Here 
					to reset your password.
				
		
		
				
				
					Instructions     
					Notification     
					Contact Us
					
				
		
			
	
	
	
	
		Forget Password ?
		
			 Enter your e-mail address below to reset your password.
		
		
			
				
				
			
		
		
			
			 Back 
			
			Submit 
			
		
	
	
	
		New Registration
		
			 Enter your e-mail address
		
		
			
				
				
			
		
		
			Name as in Records
		
		
			
				
				
			
		
		
			Date of Birth
		
		
			
				
				
			
		
		
			Registration details will be sent to your registered e-Mail ID. Please login to your Mail ID and continue the registration process.
		
		
		
			
			 Back 
			
			Submit 
			
		
	
	
	
</value>
      <webElementGuid>a1ccc228-397f-4ffd-93ea-432920c7dbb9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;login&quot;]/div[@class=&quot;content&quot;]</value>
      <webElementGuid>36d3813e-33b7-4911-84eb-639b2277b6e7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]</value>
      <webElementGuid>79fce509-ff2e-4d32-91cd-eaadf97f0021</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
	
	
		Login to your account
		  	 
		
			
			Username
			
				
				
			
		
		
			Password
			
				
				
			
		
		
			
			 Remember me 
			
			
			Login 
			
			
		
	
		
				New Registration?
				
					 
					Click Here 
					For Registration.
				
		
		
				Forgot your password ?
				
					
					Click Here 
					to reset your password.
				
		
		
				
				
					Instructions     
					Notification     
					Contact Us
					
				
		
			
	
	
	
	
		Forget Password ?
		
			 Enter your e-mail address below to reset your password.
		
		
			
				
				
			
		
		
			
			 Back 
			
			Submit 
			
		
	
	
	
		New Registration
		
			 Enter your e-mail address
		
		
			
				
				
			
		
		
			Name as in Records
		
		
			
				
				
			
		
		
			Date of Birth
		
		
			
				
				
			
		
		
			Registration details will be sent to your registered e-Mail ID. Please login to your Mail ID and continue the registration process.
		
		
		
			
			 Back 
			
			Submit 
			
		
	
	
	
' or . = '
	
	
		Login to your account
		  	 
		
			
			Username
			
				
				
			
		
		
			Password
			
				
				
			
		
		
			
			 Remember me 
			
			
			Login 
			
			
		
	
		
				New Registration?
				
					 
					Click Here 
					For Registration.
				
		
		
				Forgot your password ?
				
					
					Click Here 
					to reset your password.
				
		
		
				
				
					Instructions     
					Notification     
					Contact Us
					
				
		
			
	
	
	
	
		Forget Password ?
		
			 Enter your e-mail address below to reset your password.
		
		
			
				
				
			
		
		
			
			 Back 
			
			Submit 
			
		
	
	
	
		New Registration
		
			 Enter your e-mail address
		
		
			
				
				
			
		
		
			Name as in Records
		
		
			
				
				
			
		
		
			Date of Birth
		
		
			
				
				
			
		
		
			Registration details will be sent to your registered e-Mail ID. Please login to your Mail ID and continue the registration process.
		
		
		
			
			 Back 
			
			Submit 
			
		
	
	
	
')]</value>
      <webElementGuid>e705fe10-dad7-4a4c-b37f-b4a539ff00b5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
